year = input('연도를 입력하세요:')
year = int(year)
if year%12 == 1:
    print(year,'년생은 닭띠입니다.')
if year%12 == 2:
    print(year,'년생은 개띠입니다.')
if year%12 == 3:
    print(year,'년생은 돼지띠입니다.')
if year%12 == 4:
    print(year,'년생은 쥐띠입니다.')
if year%12 == 5:
    print(year,'년생은 소띠입니다.')
if year%12 == 6:
    print(year,'년생은 호랑이띠입니다.')
if year%12 == 7:
    print(year,'년생은 토끼띠입니다.')
if year%12 == 8:
    print(year,'년생은 용띠입니다.')
if year%12 == 9:
    print(year,'년생은 뱀띠입니다.')
if year%12 == 10:
    print(year,'년생은 말띠입니다.')
if year%12 == 11:
    print(year,'년생은 양띠입니다.')
if year%12 == 0:
    print(year,'년생은 원숭이띠입니다.')
