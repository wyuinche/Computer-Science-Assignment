a = {'초록', '빨강', '파랑'}
b = {'빨강', '노랑', '초록', '검정'}
print(a.union(b))
print(a - b)
print(a&b)
