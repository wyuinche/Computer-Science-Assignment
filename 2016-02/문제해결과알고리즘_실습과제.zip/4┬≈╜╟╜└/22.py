Python 3.4.3 (v3.4.3:9b73f1c3e601, Feb 24 2015, 22:43:06) [MSC v.1600 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> ================================ RESTART ================================
>>> 
2
dict_keys(['경석', '우성'])
dict_values([3, 2])
dict_items([('경석', 3), ('우성', 2)])
>>> 
