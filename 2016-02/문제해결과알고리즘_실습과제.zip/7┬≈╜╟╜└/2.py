a = input('원하는 단을 입력하세요 : ')
a = int(a)
for i in range( 1, 10, 1) :
    print( a, '*', i, '=', a*i )
